# CrownTrack ADV Prompt 02 Package

Use `CODEX_PROMPT_02_LOCAL_FIRST_CREWLINK.md` as the full next prompt.

Supporting files:

- `OFFGRID_BUDDY_ARCHITECTURE_BRIEF.md`
- `MINI_APP_STUDIO_QA_RULEBOOK.md`

This milestone intentionally builds protocol, local data, UI states, simulators, and a local development relay before real GPS, MapLibre, Bluetooth, Meshtastic, or production backend integration.
