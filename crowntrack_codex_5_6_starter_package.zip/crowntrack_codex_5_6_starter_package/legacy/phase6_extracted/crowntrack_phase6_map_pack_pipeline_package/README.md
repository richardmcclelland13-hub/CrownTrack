# CrownTrack ADV — Phase 6 Map Pack Pipeline Package

This package advances CrownTrack ADV from a navigation-core prototype into the next major production milestone: **offline map-pack registry and legal data pipeline**.

## Package contents

```text
crowntrack_phase6_map_pack_pipeline_package/
  FRESH_CHAT_BRIEF.md
  README.md
  source_manifest.json
  prototype/
    crowntrack_phase6_map_pack_pipeline_preview.html
    README.md
  docs/
    PROJECT_STATE_PHASE6.md
    MILESTONE_PLAN_PHASE6.md
    MAP_PACK_PIPELINE_SPEC_PHASE6.md
    MAP_STYLE_AND_TILE_SCHEMA_PHASE6.md
    DATA_INGEST_LEGAL_SOURCE_MATRIX_PHASE6.md
    MOBILE_OFFLINE_PACK_MANAGER_SPEC_PHASE6.md
    BUILDER_CONSOLE_SPEC_PHASE6.md
    QA_GATES_PHASE6.md
    BUILD_TRACKER_PHASE6.md
    ROADMAP_NEXT_STEPS.md
  codex/
    AGENTS.md
    STAGE_0_BOOTSTRAP_PROMPT.md
    STAGE_1_NATIVE_UI_SHELL_PROMPT.md
    STAGE_2A_NAVIGATION_CORE_PROMPT.md
    STAGE_3A_OFFLINE_PACK_REGISTRY_PROMPT.md
    STAGE_3B_MAPLIBRE_LOCAL_PACK_SPIKE_PROMPT.md
    STAGE_3C_GIS_PIPELINE_SCAFFOLD_PROMPT.md
    SUBAGENT_PLAYBOOK_PHASE6.md
  skills/
    source-licence-auditor/SKILL.md
    offline-map-pack-builder/SKILL.md
    native-maplibre-integration/SKILL.md
    route-legality-audit/SKILL.md
    qa-audit/SKILL.md
  research/
    OFFICIAL_RESEARCH_NOTES_PHASE6.md
  handoff/
    NEXT_CHAT_STARTER_PROMPT.md
  legacy/
    crowntrack_phase5_navigation_core_package.zip
```

## Phase 6 design intent
The prototype is no longer just an app skin. It models the relationship between:

1. Mobile app offline pack manager.
2. Pack manifest and source audit.
3. Route audit.
4. Internal pack builder pipeline.
5. SOS/rescue packet dependency on local map and GPX data.

## Next Codex stage
Use Stage 3A after the UI shell and navigation core are in place. Stage 3A builds a pure TypeScript offline pack registry with mock pack manifests, install states, source metadata, and route coverage checks. No real MapLibre or GIS yet.
