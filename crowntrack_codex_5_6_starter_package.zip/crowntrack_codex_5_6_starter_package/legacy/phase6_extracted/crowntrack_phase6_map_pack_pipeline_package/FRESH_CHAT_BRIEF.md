# CrownTrack ADV — Fresh Chat Brief (Phase 6)

You are helping Richard build **CrownTrack ADV**, a private Android/iOS offline GPS app for Alberta adventure-bike riding. Richard wants ChatGPT to act as senior product designer / architect / prompt generator, while Codex acts as coder. The workflow is staged: ChatGPT prepares package + exact Codex prompt, Richard runs Codex, then returns file tree/output/errors for audit and next prompt.

## Product vision
CrownTrack ADV is not a Gaia GPS clone in a sketchy/copy sense. It is a private Alberta ADV navigation platform inspired by field GPS tools:

- Offline map packs for Alberta riding areas.
- GPS blue-dot navigation without cell service.
- GPX import/export for tracks/routes/waypoints.
- Follow-line navigation first, not full turn-by-turn.
- Track recording and rescue GPX export.
- Alberta public land / PLUZ / crown-land trail awareness.
- Source confidence and legal-data warnings.
- Buddy sharing when online; future Meshtastic/off-grid bridge later.

## Current milestone: Phase 6
Phase 5 froze the **navigation core**. Phase 6 pushes the next major product risk: **offline map-pack system + data/source pipeline**.

The app cannot be trustworthy until every offline pack has:

- Pack manifest
- Source provenance
- Licence/attribution rules
- Tile/source format decision
- Versioning
- Hash/checksum
- Device install state
- Layer registry
- Legal/source-confidence metadata
- QA report

## Open the prototype
Open:

`prototype/crowntrack_phase6_map_pack_pipeline_preview.html`

This is a single-file offline HTML prototype. It models app UI and product state, not real MapLibre/GPS yet.

## What Codex should do next
If there is no repo yet, run:

`codex/STAGE_0_BOOTSTRAP_PROMPT.md`

If the React Native UI shell exists and Phase 5 navigation core exists, run:

`codex/STAGE_3A_OFFLINE_PACK_REGISTRY_PROMPT.md`

Then audit before continuing to MapLibre/GIS.

## Non-negotiables
- No scraping Gaia, Google, Garmin, Trailforks, BRMB, AllTrails, or OSM public tiles.
- OSM data may be used with proper ODbL attribution and generated/licensed tiles.
- Official Alberta sources must keep source date + disclaimers.
- User GPX is useful but not legal truth.
- The app must work offline-first.
- Keep UI native-feeling, calm, field-readable, and glove-friendly.
