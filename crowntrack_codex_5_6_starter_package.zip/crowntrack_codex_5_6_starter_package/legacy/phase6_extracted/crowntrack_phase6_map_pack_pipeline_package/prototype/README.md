# Phase 6 HTML Prototype

Open `crowntrack_phase6_map_pack_pipeline_preview.html` locally in a browser.

This is a self-contained HTML/CSS/JS prototype. It previews:

- Ride app map screen
- Offline pack manifest UI
- Pack install queue
- Source/licence audit
- Route audit warnings
- Internal pack builder workflow
- Rescue export concept
- Field/high-contrast mode

It does not include real GPS, real MapLibre, real map tiles, or real Alberta geospatial data.
