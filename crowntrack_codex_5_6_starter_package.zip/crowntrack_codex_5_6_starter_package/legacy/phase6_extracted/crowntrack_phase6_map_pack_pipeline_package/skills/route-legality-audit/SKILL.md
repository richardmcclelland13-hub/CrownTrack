# Skill: Route Legality / Source Confidence Audit

Use when adding route planning, route import, pack coverage, or trail display.

## Steps
1. Check route bbox against installed pack.
2. Check required layers exist.
3. Collect source confidence per route segment.
4. Warn on user-only GPX segments.
5. Warn on PLUZ/public land intersections requiring official verification.
6. Never claim legal access unless official data explicitly supports it.
7. Surface warnings clearly in UI.
