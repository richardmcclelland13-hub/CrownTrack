# Skill: QA Audit

Use after every Codex stage.

## Checklist
- Does it build?
- Do tests pass?
- Did TypeScript pass?
- Were dependencies added? Why?
- Any network calls introduced?
- Any real data fetched too early?
- Any source/legal assumptions?
- Any UI regressions?
- Any accessibility/touch target problems?
- Any offline-first violation?

## Output
Write a short audit report with pass/fail and next prompt recommendation.
