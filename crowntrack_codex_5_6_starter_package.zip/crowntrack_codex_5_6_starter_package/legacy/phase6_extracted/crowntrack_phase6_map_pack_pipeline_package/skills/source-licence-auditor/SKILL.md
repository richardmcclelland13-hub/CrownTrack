# Skill: Source Licence Auditor

Use this skill whenever adding or modifying map/data sources.

## Steps
1. Identify source title, owner, URL, access date, and licence.
2. Determine whether offline use is allowed.
3. Determine whether redistribution is allowed.
4. Determine attribution requirements.
5. Mark confidence: official, licensed, OSM, derived, user, unknown.
6. Block unknown/proprietary/scraped sources.
7. Update source manifest and docs.

## Hard stops
- No public tile scraping.
- No Gaia/Garmin/Google/Trailforks/BRMB/AllTrails copying.
- No user GPX treated as official legal access.
