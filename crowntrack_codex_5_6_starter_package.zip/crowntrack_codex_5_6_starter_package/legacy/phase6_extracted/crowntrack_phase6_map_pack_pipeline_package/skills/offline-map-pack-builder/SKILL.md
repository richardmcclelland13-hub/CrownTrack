# Skill: Offline Map Pack Builder

Use this skill when working on pack manifests, pack install state, or GIS pipeline scripts.

## Steps
1. Start with manifest schema.
2. Validate bbox, layers, sources, attribution, checksums.
3. Add state transitions.
4. Add route coverage checks.
5. Add stale/corrupt/ready states.
6. Add tests before UI wiring.
7. Update build tracker.

## Output required
- Files changed.
- Tests run.
- Assumptions.
- Source/data risks.
