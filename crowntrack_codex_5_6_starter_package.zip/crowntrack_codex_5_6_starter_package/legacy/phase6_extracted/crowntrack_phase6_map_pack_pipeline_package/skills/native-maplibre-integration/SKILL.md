# Skill: Native MapLibre Integration

Use only when the stage explicitly asks for MapLibre.

## Steps
1. Confirm current React Native architecture and Expo/bare status.
2. Add MapLibre dependency carefully.
3. Build isolated spike screen first.
4. Use local/mock style first.
5. Test mount/unmount and tab switching.
6. Document iOS/Android setup.
7. Do not connect real pack downloads until registry is stable.
