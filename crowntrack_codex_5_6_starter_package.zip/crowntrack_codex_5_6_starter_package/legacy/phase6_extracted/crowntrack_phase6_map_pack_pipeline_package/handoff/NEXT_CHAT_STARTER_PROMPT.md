# Next Chat Starter Prompt

I am building CrownTrack ADV, a private Android/iOS offline GPS app for Alberta adventure biking. You are the senior product architect/designer and Codex prompt generator. Codex is the coder.

Please read `FRESH_CHAT_BRIEF.md`, `README.md`, and the Phase 6 docs. The current milestone is Offline Map Pack Registry + Source Pipeline. The next Codex prompt should be `codex/STAGE_3A_OFFLINE_PACK_REGISTRY_PROMPT.md` if the React Native UI shell and navigation core exist. If there is no repo yet, start with Stage 0 Bootstrap.

Do not guess. Do not scrape proprietary data. Keep everything offline-first, source-aware, and stage-gated.
