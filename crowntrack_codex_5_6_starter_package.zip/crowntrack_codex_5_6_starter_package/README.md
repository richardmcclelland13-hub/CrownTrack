# CrownTrack ADV — Codex 5.6 Starter Package

Private Alberta ADV GPS app production package.

## What this package contains

- Product brief and MVP scope lock
- Native mobile UI direction for Codex 5.6
- Repo architecture and folder plan
- Data contracts for routes, tracks, offline packs, crew status, and SOS packets
- Legal/data-source guardrails
- Local skill files for Codex workflows
- Codex start prompt and staged follow-up prompts
- Latest HTML prototype/reference
- Legacy Phase 6 package for project history

## Expected build stack

- React Native + TypeScript
- Prefer Expo Dev Client / prebuild at first if it speeds development, but architect for native modules later
- MapLibre React Native later, not in the first UI shell
- SQLite/local storage later
- Pure TypeScript domain packages for navigation, GPX, offline pack registry, and route audit logic

## First Codex task

Copy the contents of:

`prompts/CODEX_START_PROJECT_PROMPT.md`

Paste that into Codex from the package/repo root.
