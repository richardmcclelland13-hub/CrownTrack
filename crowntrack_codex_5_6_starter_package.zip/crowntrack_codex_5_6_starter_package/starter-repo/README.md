# Starter Repo Placeholder

This folder describes the intended repo structure. Codex may either use this as a starting scaffold or create the actual project at the repository root.

Do not treat these placeholder folders as complete code.
