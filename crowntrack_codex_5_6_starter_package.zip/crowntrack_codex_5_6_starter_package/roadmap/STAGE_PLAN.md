# CrownTrack Stage Plan

## Stage 0 — Bootstrap

Create repo scaffold, AGENTS.md, docs, package manager, lint/typecheck/test basics.

## Stage 1 — Native UI Shell

Build app navigation and mock UI screens. No real maps/GPS/network.

## Stage 2 — Navigation Core

Pure TypeScript state machine: route, recording, waypoints, rescue packet.

## Stage 3 — Offline Pack Registry

Pure TypeScript pack manifests, source audit, attribution, install states, route coverage.

## Stage 4 — MapLibre Spike

Show one local/mock map layer through an adapter. No real production data yet.

## Stage 5 — GPX Engine

Import/export GPX routes/tracks/waypoints.

## Stage 6 — GIS Pipeline Scaffold

Create data-ingest pipeline skeleton with legal/source audit gates.

## Stage 7 — Real GPS Spike

Foreground/background location proof of concept with battery/safety constraints.

## Stage 8 — Private Crew Sync

Online-only ride room and last-known-location sync.

## Stage 9 — Meshtastic Research Spike

Evaluate Bluetooth/LoRa bridge feasibility separately.
