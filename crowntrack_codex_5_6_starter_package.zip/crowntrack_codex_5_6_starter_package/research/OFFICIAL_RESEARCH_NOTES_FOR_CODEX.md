# Official Research Notes

These are research anchors. Codex should verify current docs again before implementing any external integration.

## Codex guidance

- Codex reads `AGENTS.md` files before work and layers guidance from global/project/local files.
- Codex skills are directories with `SKILL.md`; each `SKILL.md` must include `name` and `description` metadata.
- Codex subagents are useful for parallel read/review/exploration tasks, but can consume more tokens and write-heavy parallel work can cause conflicts.

Official docs:

- https://developers.openai.com/codex/guides/agents-md
- https://developers.openai.com/codex/skills
- https://developers.openai.com/codex/subagents
- https://developers.openai.com/codex/learn/best-practices

## Mobile UI guidance

Use current Apple HIG and Android/Material guidelines when implementing.

- https://developer.apple.com/design/human-interface-guidelines/
- https://m3.material.io/
- https://developer.android.com/guide/topics/ui/accessibility/apps

## Map/offline guidance

- MapLibre React Native supports an offline manager concept.
- MapLibre Native/Android supports PMTiles sources in current versions.
- Do not bulk download public OpenStreetMap tile server tiles for offline use.

Official/source docs:

- https://maplibre.org/maplibre-react-native/docs/modules/offline-manager/
- https://www.maplibre.org/maplibre-native/android/examples/data/PMTiles/
- https://operations.osmfoundation.org/policies/tiles/

## Alberta/geospatial direction

Use official Alberta/open-data sources only when licence/offline use is confirmed.

- https://www.alberta.ca/public-land-recreation-maps
- https://www.alberta.ca/public-land-use-zones
- Alberta Crown Land Trails dataset listing / official open data references should be checked fresh before ingestion.
