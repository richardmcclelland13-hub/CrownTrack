# CrownTrack ADV — Codex 5.6 Starter Package

This package is the current production handoff for **CrownTrack ADV**, a private Android/iOS adventure-bike GPS app for Alberta riding.

The goal is not to clone Gaia GPS line-for-line. The goal is to build a **private Alberta ADV navigation app** with offline map packs, GPX follow/record, route audits, PLUZ/crown-land awareness, buddy ride rooms, and later Meshtastic/off-grid pings.

## Start order

1. Read `AGENTS.md`.
2. Read `docs/PRODUCT_BRIEF.md`.
3. Read `docs/MVP_SCOPE_LOCK.md`.
4. Read `design/UI_DIRECTION_FOR_CODEX_5_6.md`.
5. Read `architecture/REPO_ARCHITECTURE.md`.
6. Read `data-contracts/TYPESCRIPT_CONTRACTS.md`.
7. Read `prompts/CODEX_START_PROJECT_PROMPT.md`.
8. Use the local skills in `skills/*/SKILL.md` when their description matches the task.

## What Codex should build first

Codex should build a clean repo scaffold and then a high-quality React Native + TypeScript **UI shell** with mock data only.

No real GPS yet. No MapLibre yet. No real Alberta downloads yet. No API keys. No scraping.

## Current stage

**Stage 0/1 launch package** — bootstrap the repo, design the real UI shell, add mock data contracts, and establish tests/quality gates.

## Important warning

The HTML prototypes in `prototype/` are **not the final UI quality bar**. They are functional references showing screens, flows, and product concepts. Codex 5.6 should design a better native UI from the product brief and UI direction docs.
