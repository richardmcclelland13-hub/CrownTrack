# Subagent Playbook

Use subagents for read-heavy or review-heavy tasks, not for simultaneous code edits unless the boundaries are very clear.

## First-task subagents

### UI/UX subagent

Read product/design docs and return:

- screen inventory
- component hierarchy
- design token recommendation
- accessibility risks
- suggested improvements beyond the HTML prototype

### Architecture subagent

Read architecture docs and return:

- repo structure
- dependency recommendation
- package boundaries
- test strategy
- setup risks

### Data/legal subagent

Read legal/data docs and return:

- hard no data sources
- source confidence states needed in UI
- offline pack registry requirements
- attribution/unknown-state requirements

### QA subagent

Create:

- acceptance checklist
- likely regression risks
- commands to run
- manual UI verification plan

## Main agent responsibility

The main Codex agent collects the summaries, makes final decisions, writes code, runs checks, then reports results.
